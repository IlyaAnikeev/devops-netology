# Ansible Collection - my_own_namespace.yandex_cloud_elk

Коллекция для тестирования модуля (Нетология)

Описание роли: [test_role]()
